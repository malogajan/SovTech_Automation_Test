<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS_Contact_us</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>03e0d891-8b93-40d7-ad2b-b141d01d6203</testSuiteGuid>
   <testCaseLink>
      <guid>6a6b9b8a-afba-435c-b9df-e9ec2ee7d36b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Contact_us_positive</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>443267c5-93d9-4211-a6dc-9c700fbe8b90</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_Verify_Mandatory_fields</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
