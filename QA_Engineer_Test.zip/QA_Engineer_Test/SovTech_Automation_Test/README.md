# SovTech_Automation_Test
SovTech QA Engineer Test

**How to Execute the test scripts/ cases**
Pre-conditions
Install Katalon Studio Tool Installed (refer to this link https://docs.katalon.com/katalon-studio/docs/getting-started.html for installation)
On Project explorer , navigate to test cases to execute a single test or test suites to exucet a collection of test cases
