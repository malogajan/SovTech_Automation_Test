<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>img_(27) 010 865 0161_default-logo normal-logo</name>
   <tag></tag>
   <elementGuidId>85eb1b15-7d39-472c-9be1-c8033eac2df6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//img[@alt='SovTech.co.za | Software Development South Africa']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>img.default-logo.normal-logo</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>img</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>src</name>
      <type>Main</type>
      <value>https://43cvff3e0qj249vcceebsqc1-wpengine.netdna-ssl.com/wp-content/uploads/sites/29/2019/07/sovtech_logo-2.png</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>alt</name>
      <type>Main</type>
      <value>SovTech.co.za | Software Development South Africa</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>default-logo normal-logo</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>width</name>
      <type>Main</type>
      <value>220</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;page-template-default page page-id-9299 elementor-default elementor-kit-11323 elementor-page elementor-page-9299&quot;]/div[@class=&quot;saspot-main-wrap&quot;]/div[@class=&quot;main-wrap-inner&quot;]/header[@class=&quot;saspot-header  saspot-sticky&quot;]/div[@class=&quot;row align-items-center&quot;]/div[@class=&quot;col-xl-5 col-lg-4 col-md-6 col-10&quot;]/div[@class=&quot;saspot-brand&quot;]/a[1]/img[@class=&quot;default-logo normal-logo&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:img</name>
      <type>Main</type>
      <value>//img[@alt='SovTech.co.za | Software Development South Africa']</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//img</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//img[@src = 'https://43cvff3e0qj249vcceebsqc1-wpengine.netdna-ssl.com/wp-content/uploads/sites/29/2019/07/sovtech_logo-2.png' and @alt = 'SovTech.co.za | Software Development South Africa']</value>
   </webElementXpaths>
</WebElementEntity>
