import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys


// Launching Browser and navigate to SovTech Contact us page
WebUI.openBrowser('')

WebUI.navigateToUrl('https://www.sovtech.co.za/contact-us/')

WebUI.maximizeWindow()
// Verify the comapny logo display at the top left corner
WebUI.verifyElementPresent(findTestObject('Page_Contact Us - SovTech Custom Software/img_(27) 010 865 0161_default-logo normal-logo'), 
    0)

WebUI.takeScreenshot()

WebUI.setText(findTestObject('Object Repository/Page_Contact Us - SovTech Custom Software/input__your_name'), 'Jan Seopa')

WebUI.setText(findTestObject('Object Repository/Page_Contact Us - SovTech Custom Software/input__email'), 'malogajan92@gmail.com')

WebUI.setText(findTestObject('Object Repository/Page_Contact Us - SovTech Custom Software/input_Contact Number_mobilephone'), 
    '0712237561')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Contact Us - SovTech Custom Software/select_Please Select1-55-2525-5050-100100-5_1224b7'), 
    '100-500', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_Contact Us - SovTech Custom Software/select_Please SelectDevelop  launch a produ_f4ca38'), 
    'Manage & improve existing platforms', true)

WebUI.setText(findTestObject('Object Repository/Page_Contact Us - SovTech Custom Software/textarea_How can we help you_message'), 
    'IT Service')
// Click checkbox agree to receive other communications from SovTech.
WebUI.click(findTestObject('Object Repository/Page_Contact Us - SovTech Custom Software/input_How can we help you_LEGAL_CONSENT.sub_9d5c24'))

WebUI.click(findTestObject('Object Repository/Page_Contact Us - SovTech Custom Software/input_I agree to receive other communicatio_2e8b99'))
//Take the screenshot
WebUI.takeScreenshot()

WebUI.click(findTestObject('Object Repository/Page_Submission Contact Us - SovTech Custom_71052a/h2_Submission Successful'))

//Take the screenshot
WebUI.takeScreenshot()
// Close the browser once successfull message recieved
WebUI.closeBrowser('')



